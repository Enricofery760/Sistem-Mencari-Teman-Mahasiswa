package com.example.nmpseleraku

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.nmpseleraku.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_MAHASISWA = "EXTRA_MAHASISWA"
    }

    private lateinit var binding: ActivityMainBinding

    private val mahasiswaList = listOf(
        Mahasiswa(
            "Andi", "72210501", "DSAI", R.drawable.mahasiswa_andi,
            "Saya Andi, suka ngoding Android",
            "Algoritma, Machine Learning",
            "Magang di Startup"
        ),
        Mahasiswa(
            "Budi", "72210502", "SI", R.drawable.mahasiswa_budi,
            "Saya Budi, fokus di UI/UX",
            "Database, Web Programming",
            "Aktif di Organisasi Kampus"
        )
        // Tambah data lain sesuai kebutuhan
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.rvMahasiswa.layoutManager = LinearLayoutManager(this)
        binding.rvMahasiswa.adapter = MahasiswaAdapter(mahasiswaList) { mhs ->
            val intent = Intent(this, DetailActivity::class.java)
            intent.putExtra(EXTRA_MAHASISWA, mhs)
            startActivity(intent)
        }
    }
}
