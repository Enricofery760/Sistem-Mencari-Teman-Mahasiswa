package com.example.nmpseleraku

import java.io.Serializable


data class Mahasiswa(
    val nama: String,
    val nrp: String,
    val program: String,
    val fotoRes: Int,
    val about: String,
    val courses: String,
    val experiences: String
) : Serializable