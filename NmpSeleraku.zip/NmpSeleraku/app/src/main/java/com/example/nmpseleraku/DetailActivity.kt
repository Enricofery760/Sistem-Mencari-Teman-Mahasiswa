package com.example.nmpseleraku

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.nmpseleraku.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val mhs = intent.getSerializableExtra(MainActivity.EXTRA_MAHASISWA) as? Mahasiswa ?: return

        binding.ivFotoDetail.setImageResource(mhs.fotoRes)
        binding.tvNamaDetail.text = mhs.nama
        binding.tvNrpDetail.text = mhs.nrp

        // Spinner
        val opsi = arrayOf(getString(R.string.about), getString(R.string.course), getString(R.string.experiences))
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, opsi)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerDetail.adapter = adapter

        binding.spinnerDetail.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
                binding.tvIsiDetail.text = when (pos) {
                    0 -> mhs.about
                    1 -> mhs.courses
                    2 -> mhs.experiences
                    else -> ""
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        // RadioGroup sesuai program
        when (mhs.program) {
            "DSAI" -> binding.rgProgram.check(R.id.rbDSAI)
            "SI"   -> binding.rgProgram.check(R.id.rbSI)
            "SE"   -> binding.rgProgram.check(R.id.rbSE)
            else -> binding.rgProgram.clearCheck()
        }

        // Button Request Friend
        binding.btnRequestFriend.setOnClickListener {
            FriendManager.addFriend()
            AlertDialog.Builder(this)
                .setTitle("Sukses")
                .setMessage("Berhasil menambah friend!\nJumlah friend: ${FriendManager.friendCount}")
                .setPositiveButton("OK", null)
                .show()
        }
    }
}
