package com.example.nmpseleraku

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.nmpseleraku.databinding.ItemMahasiswaBinding

class MahasiswaAdapter(
    private val list: List<Mahasiswa>,
    private val onClick: (Mahasiswa) -> Unit
) : RecyclerView.Adapter<MahasiswaAdapter.VH>() {

    inner class VH(val binding: ItemMahasiswaBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemMahasiswaBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val m = list[position]
        holder.binding.ivFoto.setImageResource(m.fotoRes)
        holder.binding.tvNama.text = m.nama
        holder.binding.tvNrp.text = m.nrp
        holder.binding.root.setOnClickListener { onClick(m) }
    }

    override fun getItemCount(): Int = list.size
}
