package com.example.nmpseleraku

object FriendManager {
    var friendCount: Int = 0
    fun addFriend() { friendCount++ }
}